# Straight Up Digital — logo kit

Primary wordmark color treatment: **STRAIGHT UP** in white and **DIGITAL** in electric lime green (`#B7FF00`). The S symbol in every lockup is the exact supplied 1254 × 1254 RGBA PNG; it has not been redrawn, recolored, or reshaped.

## Company-name lockups
- `lockups/horizontal-white-lime-1680px.png` and `lockups/stacked-white-lime-900px.png` — transparent PNG logo lockups.
- Matching 2× PNG, SVG and PDF versions are included in `lockups/`. SVG/PDF lockups embed the supplied raster symbol; the company-name text remains editable in SVG. The S is not vector paths.

## Symbol-only exports
- `png/straight-up-digital-symbol-master-1254.png` — exact supplied symbol master, original dimensions.
- `png/straight-up-digital-symbol-1024.png` through `-32.png` — transparent size exports.
- `svg/straight-up-digital-symbol.svg` — SVG wrapper around the exact PNG.
- `pdf/straight-up-digital-symbol-1254.pdf` — print PDF.

The wordmark color treatment is intended for dark backgrounds. The source symbol itself remains unchanged.
